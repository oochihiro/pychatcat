# 项目结构说明

## 📁 目录结构

```
python-learning-assistant/
├── main.py                    # 主程序入口
├── requirements.txt           # 项目依赖
├── README.md                  # 项目说明文档
├── .gitignore                 # Git忽略文件
│
├── core/                      # 核心功能模块
│   ├── __init__.py
│   ├── file_manager.py       # 文件管理
│   ├── code_executor.py      # 代码执行器
│   ├── deepseek_client.py    # DeepSeek AI客户端
│   └── sqlite_analytics.py   # SQLite数据分析
│
├── ui/                        # 用户界面组件
│   ├── __init__.py
│   ├── pixel_code_editor.py  # 代码编辑器
│   ├── pixel_console.py      # 输出控制台
│   ├── pixel_ai_assistant.py # AI助手面板
│   └── debugger_panel.py     # 调试器面板
│
├── backend/                   # 后端API服务
│   ├── app.py                # Flask应用
│   ├── requirements.txt      # 后端依赖
│   └── templates/            # HTML模板（可选）
│
├── integrations/              # 集成模块
│   ├── sqlite_integration.py # SQLite数据采集集成
│   └── analytics_integration.py  # 旧版分析集成（可选）
│
├── examples/                  # 示例代码
│   └── basic_python_examples.py
│
├── data/                      # 数据目录（本地，不上传）
│   ├── __init__.py
│   ├── backups/              # 备份文件
│   └── recent_files.txt      # 最近文件记录
│
├── logs/                      # 日志目录（本地，不上传）
│
├── docs/                      # 文档目录
│   ├── 使用指南.txt
│   ├── 项目说明.md
│   ├── 数据分析方案.md
│   ├── SQLite数据分析系统说明.md
│   └── 部署指南.md
│
├── scripts/                   # 工具脚本
│   ├── start_sqlite_system.py
│   └── deploy.sh             # 部署脚本（可选）
│
└── cat_icon.py               # 应用程序图标生成

```

## 📦 文件分类

### 核心代码
- `main.py` - 主程序入口
- `core/` - 核心功能模块
- `ui/` - 用户界面组件
- `integrations/` - 数据采集集成

### 后端服务
- `backend/` - Flask API服务

### 配置和依赖
- `requirements.txt` - Python依赖
- `backend/requirements.txt` - 后端依赖
- `.gitignore` - Git忽略规则

### 文档
- `README.md` - 项目主文档
- `docs/` - 详细文档

### 工具脚本
- `scripts/` - 部署和启动脚本

### 示例代码
- `examples/` - Python学习示例

## 🚀 部署相关

### 服务器部署需要
- `backend/` 目录及其所有文件
- `core/sqlite_analytics.py`
- `backend/requirements.txt`

### 客户端部署需要
- 所有 `core/`, `ui/`, `integrations/` 目录
- `main.py`
- `requirements.txt`
- `cat_icon.py`

## 📝 注意事项

1. **不上传到Git的文件**：
   - `data/*.db` - 数据库文件
   - `logs/` - 日志文件
   - `__pycache__/` - Python缓存
   - `*.pyc` - 编译文件

2. **需要配置的文件**：
   - 创建 `data/config.json` 配置后端地址（可选）

3. **环境变量**：
   - 可以创建 `.env.example` 作为模板




