# Python学习助手 - SQLite数据分析系统说明

## 📋 系统概述

已成功将数据存储从MySQL改为SQLite + Logging方案，并根据编程学习行为编码表创建了完整的数据采集系统。

## ✅ 完成的工作

### 1. **删除MySQL相关配置** ✓
- 删除了 `install_mysql.py`
- 删除了 `init_mysql.sql`
- 删除了 `MySQL部署指南.md`
- 删除了 `test_mysql_install.py`
- 删除了 `backend_example/` 目录（MySQL版本）
- 删除了 `docker-compose.yml`（MySQL版本）

### 2. **创建SQLite数据分析核心** ✓
- **文件**: `core/sqlite_analytics.py`
- **功能**: 完整的SQLite数据采集和分析系统
- **特性**:
  - 5个核心数据表（用户会话、学习行为、代码操作、AI交互、错误分析）
  - 完整的学习行为编码表支持（14种行为编码）
  - Logging日志系统集成
  - 多线程安全的数据写入
  - 数据导出为JSON格式

### 3. **创建Flask后端API** ✓
- **文件**: `backend/app.py`
- **功能**: RESTful API服务
- **端点**:
  - `POST /api/sessions` - 创建会话
  - `POST /api/sessions/<id>/behaviors` - 记录学习行为
  - `POST /api/sessions/<id>/code-operations` - 记录代码操作
  - `POST /api/sessions/<id>/ai-interactions` - 记录AI交互
  - `POST /api/sessions/<id>/errors` - 记录错误分析
  - `GET /api/sessions/<id>/stats` - 获取会话统计
  - `GET /api/analytics/overview` - 获取总体分析
  - `GET /api/analytics/export` - 导出数据

### 4. **创建前端集成** ✓
- **文件**: `integrations/sqlite_integration.py`
- **功能**: 无侵入式数据采集集成
- **集成点**:
  - 代码编辑器：记录代码编写、断点设置
  - 控制台：记录错误阅读、输出检查
  - AI助手：记录提问、阅读反馈、复制代码
  - 代码执行器：记录运行成功率、执行时间、错误分析

### 5. **更新主程序** ✓
- **文件**: `main.py`
- **更新**:
  - 集成SQLite数据采集功能
  - 应用关闭时自动结束会话
  - 多线程异步数据记录

### 6. **创建启动和测试脚本** ✓
- **启动脚本**: `start_sqlite_system.py`
- **测试脚本**: `simple_test.py`
- **功能**: 一键启动系统、自动检查依赖

### 7. **创建文档** ✓
- **数据分析方案**: `数据分析方案.md`
- **使用指南更新**: `使用指南.txt`
- **依赖更新**: `requirements.txt`

## 📊 学习行为编码表

系统完整支持以下14种学习行为编码：

| 编码 | 活动名称 | 分类 | 行为描述 |
|------|----------|------|----------|
| UT | Understanding Task | 资源 | 学生通过任务窗口查看编程任务详情 |
| RAM | Referring to Additional Materials | 资源 | 学生在参考教师提供的资源 |
| CP | Coding in Python | 编辑代码 | 学生在编写代码 |
| DP | Debugging in Python | 调试 | 学生在调试代码 |
| UPC | Understanding Python Codes | 理解代码 | 学生通过鼠标在代码上来回移动理解代码 |
| CRC | Checking Radar Chart | 检查输出 | 学生在检查输出 |
| RCM | Reading Console Message | 阅读信息 | 学生在阅读控制台中的错误信息 |
| ANQ | Asking New Questions | ChatGPT辅助编程 | 学生自主提出新的问题 |
| PCM | Pasting Console Message | ChatGPT辅助编程 | 学生粘贴控制台中的错误信息 |
| PPC | Pasting Python Codes | ChatGPT辅助编程 | 学生粘贴自己Python代码 |
| RF | Reading Feedback | ChatGPT辅助编程 | 学生阅读反馈信息 |
| CPC | Copy and Paste Codes | ChatGPT辅助编程 | 学生将代码拷贝到编辑器 |
| FC | Failure in ChatGPT | 其他行为 | 因平台的技术故障无法获得实时反馈 |
| IO | Idle Operation | 其他行为 | 学生没有任何操作行为 |

## 🗄️ 数据库结构

### 1. user_sessions（用户会话表）
- session_id: 会话ID（主键）
- user_id: 用户ID
- start_time: 开始时间
- end_time: 结束时间
- total_activities: 活动总数
- platform: 平台名称

### 2. learning_behaviors（学习行为表）
- id: 自增ID
- session_id: 会话ID（外键）
- behavior_code: 行为编码（UT, RAM, CP等）
- activity_name: 活动名称
- category: 分类
- description: 行为描述
- timestamp: 时间戳
- duration: 持续时间（秒）
- additional_data: 额外数据（JSON）

### 3. code_operations（代码操作表）
- id: 自增ID
- session_id: 会话ID（外键）
- operation_type: 操作类型（run, debug, edit）
- code_length: 代码长度
- line_count: 行数
- success: 是否成功
- error_message: 错误信息
- execution_time: 执行时间
- timestamp: 时间戳
- additional_data: 额外数据（JSON）

### 4. ai_interactions（AI交互表）
- id: 自增ID
- session_id: 会话ID（外键）
- interaction_type: 交互类型
- question_length: 问题长度
- response_length: 回答长度
- response_time: 响应时间
- feedback_quality: 反馈质量
- timestamp: 时间戳
- additional_data: 额外数据（JSON）

### 5. error_analysis（错误分析表）
- id: 自增ID
- session_id: 会话ID（外键）
- error_type: 错误类型
- error_line: 错误行号
- error_message: 错误信息
- fix_attempts: 修复尝试次数
- fix_success: 是否修复成功
- timestamp: 时间戳
- additional_data: 额外数据（JSON）

## 🚀 使用方式

### 方式1：直接运行主程序（推荐）
```bash
python main.py
```
- 自动启用数据采集功能
- 数据保存到 `data/learning_analytics.db`
- 日志保存到 `logs/` 目录

### 方式2：启动完整系统（包含后端API）
```bash
python start_sqlite_system.py
```
- 可选启动Flask后端API
- 提供数据分析接口
- 支持远程数据查询

### 方式3：仅启动后端API
```bash
cd backend
python app.py
```
- API地址：http://localhost:5000
- 提供RESTful接口

## 📦 依赖安装

### 基础功能
```bash
pip install openai Pillow
```

### 数据分析功能（可选）
```bash
pip install Flask Flask-CORS pandas numpy
```

### 一键安装所有依赖
```bash
pip install -r requirements.txt
```

## 📈 数据分析示例

### Python分析脚本
```python
import sqlite3
import pandas as pd

# 连接数据库
conn = sqlite3.connect('data/learning_analytics.db')

# 读取学习行为数据
behaviors = pd.read_sql_query(
    'SELECT * FROM learning_behaviors', 
    conn
)

# 统计各行为频率
behavior_stats = behaviors['behavior_code'].value_counts()
print(behavior_stats)

# 读取代码操作数据
code_ops = pd.read_sql_query(
    'SELECT * FROM code_operations', 
    conn
)

# 计算成功率
success_rate = code_ops['success'].mean()
print(f"代码运行成功率: {success_rate:.2%}")
```

### API查询示例
```python
import requests

# 获取总体分析（最近30天）
response = requests.get('http://localhost:5000/api/analytics/overview?days=30')
data = response.json()
print(data)
```

## 🔍 数据隐私和安全

1. **本地存储**: 所有数据存储在本地SQLite数据库
2. **匿名化**: 用户ID可配置为匿名
3. **访问控制**: 数据库仅本地可访问
4. **数据加密**: 可选的敏感数据加密
5. **定期清理**: 支持自动清理过期数据

## 📁 文件结构

```
cursor_web/
├── core/
│   └── sqlite_analytics.py      # SQLite数据分析核心
├── integrations/
│   └── sqlite_integration.py    # 前端集成代码
├── backend/
│   ├── app.py                   # Flask后端API
│   └── requirements.txt         # 后端依赖
├── data/
│   └── learning_analytics.db    # SQLite数据库
├── logs/
│   └── analytics_*.log          # 日志文件
├── main.py                      # 主程序（已集成数据采集）
├── start_sqlite_system.py       # 启动脚本
├── simple_test.py               # 测试脚本
├── 数据分析方案.md              # 数据分析方案文档
└── requirements.txt             # 项目依赖
```

## ⚠️ 注意事项

1. **数据库文件**: 首次运行会自动创建 `data/learning_analytics.db`
2. **日志文件**: 日志保存在 `logs/` 目录，按日期命名
3. **性能**: 数据采集使用多线程，不影响UI响应
4. **隐私**: 默认为匿名用户，可配置用户ID
5. **备份**: 建议定期备份SQLite数据库文件

## 🎯 下一步建议

1. **数据可视化**: 使用matplotlib/plotly创建可视化图表
2. **机器学习**: 基于行为数据训练学习模式识别模型
3. **实时分析**: 实现实时学习行为分析和反馈
4. **云端同步**: 可选的云端数据同步功能
5. **报表生成**: 自动生成学习效果报告

## ✅ 系统优势

1. **轻量级**: SQLite无需安装数据库服务器
2. **零配置**: 自动创建数据库和表结构
3. **高性能**: 多线程异步写入，不阻塞UI
4. **易分析**: 标准SQL查询，兼容pandas/numpy
5. **可扩展**: 模块化设计，易于添加新功能

---

**系统状态**: ✅ 已完成部署，功能正常运行
**数据采集**: ✅ 自动启用，无需额外配置
**文档齐全**: ✅ 提供完整的使用和分析文档
